define({
	root: {"floatingmenu.tab.abbr":"Abbreviation","button.addabbr.tooltip":"insert abbreviation","button.abbr.tooltip":"format as abbreviation","newabbr.defaulttext":"Abbr"}
,	"de":true
});