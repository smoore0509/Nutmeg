define({
	root: {"size.natural": "Original size","button.addimg.tooltip":"add image ref","floatingmenu.tab.img":"Image","floatingmenu.tab.formatting":"Formatting","floatingmenu.tab.resize":"Resize","floatingmenu.tab.crop":"Crop","button.uploadimg.tooltip":"Upload img","button.uploadimg.label":"Upload","button.img.align.left.tooltip":"Left align","button.img.align.right.tooltip":"Right Align","button.img.align.none.tooltip":"No alignment","field.img.title.label":"","field.img.title.tooltip":"","field.img.src.label":"","field.img.src.tooltip":"","border":"Add Border to Image","padding.increase":"Increase Padding","padding.decrease":"Decrease Padding","size.increase":"Increase Size","size.decrease":"Decrease Size","Resize":"Resize","Crop":"Crop","Reset":"Reset","Accept":"Accept","Cancel":"Cancel","height":"Height","width":"Width","button.toggle.tooltip": "Toggle keep aspect ratio"},
	cz: true,
	de: true,
	fr: true,
	ru: true
});
