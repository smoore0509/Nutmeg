* More config options : file-type filter
* Configurable Uploader