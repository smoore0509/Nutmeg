define({
	root: {"button.addlink.tooltip":"Insert Link","button.removelink.tooltip":"Remove Link","newlink.defaulttext":"New Link","floatingmenu.tab.link":"Link"}
,	"de":true,
	"fr":true,
	"pl":true,
	"ru":true
});