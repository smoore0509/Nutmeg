define( {
	'jgrid.locale' : 'de',
	'button.switch-metaview.tooltip': 'Zwischen Metaansicht und normaler Ansicht umschalten',
	'Browsing' : 'Durchsuche',
	'Searching for' : 'Suche nach',
	'in' : 'in',
	'Viewing' : 'Zeige',
	'numerous' : 'vielen',
	'of' : 'von',
	'Close' : 'Schließen',
	'Open' : 'Öffnen',
	'Search' : 'Suchen',
	'Name' : 'Name',
	'URL' : 'URL',
	'Preview' : 'Vorschau',
	'No records to view' : 'Keine Objekte gefunden',
	'Input search text...' : 'Suchtext eingeben...'
} );