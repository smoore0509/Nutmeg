define({
	root: { "headerids.label.target": "Target", "headerids.button.reset":"Reset","headerids.button.set":"Set","internal_hyperlink":"Internal Hyperlink" },
	"de":true,
	"en":true
});