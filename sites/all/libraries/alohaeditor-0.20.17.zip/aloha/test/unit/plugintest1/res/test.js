define( [], function() {
	return {
		status: 'ok'
	}
});