define({
	root: { "plugin2.test1": "fallback" },
	"en":true
});